from django.shortcuts import render, redirect
from app.models import Users, Post, Follow, Comment, Likes, SearchLog, Report
from core.engine import ASnapGraphEngine

# ==========================================
# 1. Home & Alerts
# ==========================================
def home(request):
    posts = Post.objects.all().order_by('-created_at')
    return render(request, '1-1.home.html', {'posts': posts})

def alert(request):
    reports = Report.objects.all().order_by('-created_at')
    return render(request, '1-2.alert.html', {'reports': reports})


# ==========================================
# 2. Explore (Advanced Bot Detection Dashboard)
# ==========================================
def explore(request):
    bots_rule1, bots_rule2, bots_rule3, bots_rule4, bots_rule5 = [], [], [], [], []
    bots_6, bots_7, bots_8, bots_9, bots_11 = [], [], [], [], []
    all_bots = set()

    users = list(Users.objects.all())
    posts = list(Post.objects.all())
    follows = list(Follow.objects.all())
    comments = list(Comment.objects.all())
    likes = list(Likes.objects.all())
    search_logs = list(SearchLog.objects.all())
    
    engine = ASnapGraphEngine()
    engine.load_data(users, posts, follows, comments, likes, search_logs)
    
    try:
        bots_rule1 = engine.detect_high_activity_after_registration()
        bots_rule2 = engine.detect_ip_duplication()
        bots_rule3 = engine.detect_spam_keywords()
        bots_rule4 = engine.detect_burst_posting()          
        bots_rule5 = engine.detect_abnormal_follow_ratio()   
        bots_6 = engine.detect_comment_spam()
        bots_7 = engine.detect_burst_commenting()
        bots_8 = engine.detect_burst_liking()
        bots_9 = engine.detect_automated_reactions()
        bots_11 = engine.detect_inconsistent_flow()

        all_bots = set(
            bots_rule1 + bots_rule2 + bots_rule3 + bots_rule4 + bots_rule5 + 
            bots_6 + bots_7 + bots_8 + bots_9 + bots_11
        )
    except Exception as e:
        print(f"🚨 Exception occurred during engine execution: {e}")

    # 🖥️ Enterprise Security Dashboard Stream Output
    print("\n" + "="*60)
    print("📢 [ASNAP CORE BOT DETECTION ENGINE VERIFICATION METRICS]")
    print("="*60)
    print(f"👉 Rule 01 (Registration Phase High Activity) : {len(bots_rule1)} bot(s) flags")
    print(f"👉 Rule 02 (IP Address Abuse/Multi-Account)  : {len(bots_rule2)} bot(s) flags")
    print(f"👉 Rule 03 (Spam Keyword Payload Detection)  : {len(bots_rule3)} bot(s) flags")
    print(f"👉 Rule 04 (Burst Posting Spike / Anomalous) : {len(bots_rule4)} bot(s) flags")
    print(f"👉 Rule 05 (Abnormal Out-Degree Graph Ratio) : {len(bots_rule5)} bot(s) flags")
    print(f"👉 Rule 06 (Identical Comment Flooding)       : {len(bots_6)} bot(s) flags")
    print(f"👉 Rule 07 (High-Velocity Burst Commenting)   : {len(bots_7)} bot(s) flags")
    print(f"👉 Rule 08 (High-Velocity Burst Liking)       : {len(bots_8)} bot(s) flags")
    print(f"👉 Rule 09 (Automated Fast Macro Reactions)   : {len(bots_9)} bot(s) flags")
    print(f"👉 Rule 11 (Inconsistent Node Traffic Flow)   : {len(bots_11)} bot(s) flags")
    print("-" * 60)
    print(f"🚀 TOTAL DEDUPLICATED REAL-TIME BOTS BLOCKED   : {len(all_bots)} malicious account(s)")
    print("="*60 + "\n")
    
    context = {
        'total_users': len(users),
        'bot_count': len(all_bots),
        'bots': list(all_bots),
        'rule4_burst_bots': bots_rule4, 
        'rule5_graph_bots': bots_rule5,
    }

    return render(request, '2-1.explore.html', context)


# ==========================================
# 3. Post Creation
# ==========================================
def create_post(request):
    return render(request, '3-1.create_post.html')


# ==========================================
# 4. My Profile & Feeds
# ==========================================
def my_profile(request):
    return render(request, '4-1.my_profile.html')

def connections(request):
    return render(request, '4-2.connections.html')

def feed(request):
    return render(request, '4-3.feed.html')


# ==========================================
# 5. Auth & Actions
# ==========================================
def login_view(request):
    return render(request, '5-1.login.html')

def signup(request):
    return render(request, '5-2.signup.html')

def likes_view(request):
    return render(request, '5-3.likes.html')


# ==========================================
# 6. Friends Profile & Actions (Fallback Mapping)
# ==========================================
def friends_profile(request, user_id=None):
    return render(request, '6-1.friends_profile.html', {'target_id': user_id})

def friends_connections(request, user_id=None):
    return render(request, '6-2.friends_connections.html', {'target_id': user_id})

def friends_feed(request, user_id=None):
    return render(request, '6-3.friends_feed.html', {'target_id': user_id})