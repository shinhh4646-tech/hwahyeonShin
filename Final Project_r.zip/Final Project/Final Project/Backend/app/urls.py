from django.urls import path
from app import views

urlpatterns = [
    
    path('', views.home, name='home'), 
    
    path('1-1.home.html', views.home, name='home_html'),
    path('1-2.alert.html', views.alert, name='alert'),
    path('2-1.explore.html', views.explore, name='explore'),
    path('3-1.create_post.html', views.create_post, name='create_post'),
    path('4-1.my_profile.html', views.my_profile, name='my_profile'),
    path('4-2.connections.html', views.connections, name='connections'),
    path('4-3.feed.html', views.feed, name='feed'),
    path('5-1.login.html', views.login_view, name='login'),
    path('5-2.signup.html', views.signup, name='signup'),
    path('5-3.likes.html', views.likes_view, name='likes'),
    path('6-1.friends_profile.html', views.friends_profile, name='friends_profile_static'),
    path('6-2.friends_connections.html', views.friends_connections, name='friends_connections_static'),
    path('6-3.friends_feed.html', views.friends_feed, name='friends_feed_static'),
    
    path('friends/<int:user_id>/profile/', views.friends_profile, name='friends_profile'),
    path('friends/<int:user_id>/connections/', views.friends_connections, name='friends_connections'),
    path('friends/<int:user_id>/feed/', views.friends_feed, name='friends_feed'),
]