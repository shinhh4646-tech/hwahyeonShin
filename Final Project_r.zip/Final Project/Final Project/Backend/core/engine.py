from collections import defaultdict, deque
from datetime import timedelta
from django.utils import timezone

class ASnapGraphEngine:
    def __init__(self):
        self.users = []
        self.posts = []
        self.follows = []
        self.comments = []  
        self.likes = []     
        self.search_logs = []
        
    def load_data(self, users, posts, follows, comments, likes, search_logs):
        self.users = users
        self.posts = posts
        self.follows = follows
        self.comments = comments
        self.likes = likes
        self.search_logs = search_logs

    
    def _get(self, obj, key):
        if obj is None:
            return None
        # 1. 딕셔너리 형태일 때 처리
        if isinstance(obj, dict):
            val = obj.get(key)
            if val is None and key == 'user_id': val = obj.get('user')
            if val is None and key == 'post_id': val = obj.get('post')
            if val is None and key == 'follower_id': val = obj.get('follower')
            if val is None and key == 'following_id': val = obj.get('following')
            return val
        # 2. 장고 객체 형태일 때 처리
        val = getattr(obj, key, None)
        if val is None and key == 'user_id': val = getattr(obj, 'user', None)
        if val is None and key == 'post_id': val = getattr(obj, 'post', None)
        if val is None and key == 'follower_id': val = getattr(obj, 'follower', None)
        if val is None and key == 'following_id': val = getattr(obj, 'following', None)
        
        # 외래키 객체 자체가 뽑혔다면 ID 값만 추출
        if hasattr(val, 'id'):
            return val.id
        return val

    # [1번 로직] 가입 직후 비정상적 활동 (1시간 내 액션 50개 이상)
    def detect_high_activity_after_registration(self):
        now = timezone.now()
        recent_users = set()
        for u in self.users:
            uid = self._get(u, 'id')
            created = self._get(u, 'created_at')
            if uid and created and (now - created) <= timedelta(hours=1):
                recent_users.add(uid)
        
        post_counts = defaultdict(int)
        for post in self.posts:
            uid = self._get(post, 'user_id')
            if uid in recent_users:
                post_counts[uid] += 1
                
        return [uid for uid, count in post_counts.items() if count > 50]

    # [2번 로직] IP 주소 중복 (같은 IP로 5개 이상 계정 생성)
    def detect_ip_duplication(self):
        ip_counts = defaultdict(list)
        for user in self.users:
            ip = self._get(user, 'last_login_ip')
            uid = self._get(user, 'id')
            if ip and uid:
                ip_counts[ip].append(uid)
                
        bots = []
        for ip, user_ids in ip_counts.items():
            if len(user_ids) > 5:
                bots.extend(user_ids)
        return bots

    # [3번 로직] 스팸 키워드 필터링
    def detect_spam_keywords(self):
        spam_keywords = ['gambling', 'ads', 'link']
        bots = set()
        for post in self.posts:
            content = self._get(post, 'content')
            uid = self._get(post, 'user_id')
            if content and uid:
                if any(k in content.lower() for k in spam_keywords):
                    bots.add(uid)
        return list(bots)

    # [4번 로직] Burst Posting (슬라이딩 윈도우 알고리즘)
    def detect_burst_posting(self):
        user_post_times = defaultdict(list)
        for post in self.posts:
            uid = self._get(post, 'user_id')
            t = self._get(post, 'created_at')
            if uid and t:
                user_post_times[uid].append(t)
            
        bots = set()
        for user_id, times in user_post_times.items():
            times.sort()
            window = deque()
            for t in times:
                window.append(t)
                while window and (t - window[0]).total_seconds() > 60:
                    window.popleft()
                if len(window) > 100:
                    bots.add(user_id)
                    break 
        return list(bots)

    # [5번 로직] 비정상적 팔로우 비율 (그래프 구조 분석)
    def detect_abnormal_follow_ratio(self):
        in_degree = defaultdict(int)
        out_degree = defaultdict(int)
        for f in self.follows:
            follower = self._get(f, 'follower_id')
            following = self._get(f, 'following_id')
            if follower and following:
                out_degree[follower] += 1
                in_degree[following] += 1
            
        bots = []
        for user in self.users:
            uid = self._get(user, 'id')
            if uid and in_degree[uid] == 0 and out_degree[uid] > 1000:
                bots.append(uid)
        return bots
    
    # [6번 로직] 댓글 도배 (동일 내용 10번 이상 반복)
    def detect_comment_spam(self):
        comment_map = defaultdict(int)
        for c in self.comments:
            uid = self._get(c, 'user_id')
            content = self._get(c, 'content')
            if uid and content:
                comment_map[(uid, content)] += 1
        return list({uid for (uid, content), count in comment_map.items() if count > 10})

    # [7, 8번 공용 로직] 단시간 과도한 액션 탐지 (슬라이딩 윈도우)
    def _check_burst_action(self, action_data, threshold=100):
        user_action_times = defaultdict(list)
        for action in action_data:
            uid = self._get(action, 'user_id')
            t = self._get(action, 'created_at')
            if uid and t:
                user_action_times[uid].append(t)
            
        bots = set()
        for uid, times in user_action_times.items():
            times.sort()
            window = deque()
            for t in times:
                window.append(t)
                while window and (t - window[0]).total_seconds() > 60:
                    window.popleft()
                if len(window) > threshold:
                    bots.add(uid)
                    break
        return list(bots)

    def detect_burst_commenting(self): 
        return self._check_burst_action(self.comments, 100)

    def detect_burst_liking(self): 
        return self._check_burst_action(self.likes, 100)

    # [9번 로직] 자동 좋아요 감지 (게시물 생성 후 0.1초 내 반응 매크로)
    def detect_automated_reactions(self):
        post_time_map = {}
        for p in self.posts:
            pid = self._get(p, 'id')
            t = self._get(p, 'created_at')
            if pid and t:
                post_time_map[pid] = t
                
        bots = set()
        for l in self.likes:
            pid = self._get(l, 'post_id')
            l_time = self._get(l, 'created_at')
            uid = self._get(l, 'user_id')
            if pid in post_time_map and l_time and uid:
                diff = (l_time - post_time_map[pid]).total_seconds()
                if 0 <= diff < 0.1: 
                    bots.add(uid)
        return list(bots)

    # [11번 로직] 유입 경로 부정확 (검색 기록 대비 팔로우 과다)
    def detect_inconsistent_flow(self):
        search_counts = defaultdict(int)
        for s in self.search_logs:
            uid = self._get(s, 'user_id')
            if uid: search_counts[uid] += 1
            
        follow_counts = defaultdict(int)
        for f in self.follows:
            follower = self._get(f, 'follower_id')
            if follower: follow_counts[follower] += 1
            
        bots = []
        for uid, f_count in follow_counts.items():
            s_count = search_counts.get(uid, 0)
            if f_count > (s_count * 5):
                bots.append(uid)
        return bots